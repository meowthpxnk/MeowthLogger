from .formatter import AbstractFormatter


class DefaultFormatter(AbstractFormatter):
    pass
